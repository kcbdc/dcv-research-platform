Package status: DRAFT_REQUIRES_REVIEW. Generated 2026-10-04T22:11:25.861Z.

This is an AI-assisted research draft. Real authors must verify every claim, citation, ethics declaration and journal requirement before submission. Journal acceptance has not been obtained.

Blocking issues:
- Frozen research protocol missing
- Historical panel incomplete (target 81)
- Fewer than 32 quality-controlled main_v2 human participants
- Quality-controlled human correct/error strata below predeclared minimum
- Raw simulation aggregates missing for reproduction
- Official three-year journal eligibility evidence missing or below threshold
- Target journal not selected
- Real authors, affiliations and corresponding author incomplete
- Human-research ethics/consent statement not supplied
- Author-confirmed funding and conflict declarations incomplete
- Fewer than 15 DOI-verified references
- Full-text support verification missing for key literature
- Manuscript section missing: abstract
- Manuscript section missing: introduction
- Manuscript section missing: related_work
- Manuscript section missing: methods
- Manuscript section missing: results
- Manuscript section missing: discussion
- Manuscript section missing: conclusion
- Submission document missing: cover_letter
- Submission document missing: title_page
- Submission document missing: highlights
- Submission document missing: appendices
- Main manuscript below 3500-word internal review floor
- Complete simulation seed replay has not been independently verified